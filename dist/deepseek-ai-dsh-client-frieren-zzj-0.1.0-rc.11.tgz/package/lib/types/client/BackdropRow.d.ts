/**
 * Content-backdrop row in the Frieren theme section: auto / translucent /
 * solid segmented control deciding how much the content area separates from
 * the wallpaper behind it. In auto mode a bright or warm custom wallpaper
 * (perceived brightness above threshold, sampled at upload) automatically
 * solidifies the content backdrop.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ContentBackdropMode } from '../frieren-settings.ts';
/** Registrant-private business face: the backdrop write plus its observable. */
export interface BackdropRowInjected {
    /** Persist the content-backdrop separation mode. */
    setBackdrop: (mode: ContentBackdropMode) => void;
    /** Bare observable of the current backdrop mode. */
    hooks: {
        backdrop: {
            getSnapshot(): ContentBackdropMode;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type BackdropRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<BackdropRowInjected>;
/**
 * Render the content-backdrop segmented row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function BackdropRow({ t, setBackdrop, useBackdrop }: BackdropRowProps): import("react").JSX.Element;
//# sourceMappingURL=BackdropRow.d.ts.map