/**
 * Decoration toggle row in the Frieren theme section: one chip per stage
 * layer (sparkles, blossoms, magic circle, ribbon, vignette), each writing a
 * flat boolean field of the durable `frieren-zzj` settings section.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { DecorState } from '../frieren-settings.ts';
/** Registrant-private business face: per-layer writes plus the live decor state. */
export interface DecorRowInjected {
    /** Persist one decoration layer switch. */
    setDecor: (field: keyof DecorState, enabled: boolean) => void;
    /** Bare observable of the full decoration state. */
    hooks: {
        decor: {
            getSnapshot(): DecorState;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type DecorRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<DecorRowInjected>;
/**
 * Render the decoration toggle row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function DecorRow({ t, setDecor, useDecor }: DecorRowProps): import("react").JSX.Element;
//# sourceMappingURL=DecorRow.d.ts.map