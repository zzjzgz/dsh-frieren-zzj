import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { GlassMode, GlassParams } from '../frieren-settings.ts';
/** Registrant-private business face: glass writes plus both modes' observables. */
export interface GlassRowInjected {
    /** Persist one glass param of one mode. */
    setGlass: (mode: GlassMode, field: keyof GlassParams, value: number) => void;
    /** Bare observables of the two modes' glass params. */
    hooks: {
        glassLight: {
            getSnapshot(): GlassParams;
            subscribe(fn: () => void): () => void;
        };
        glassDark: {
            getSnapshot(): GlassParams;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type GlassRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<GlassRowInjected>;
/**
 * Render the glassmorphism row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function GlassRow({ t, setGlass, useGlassLight, useGlassDark }: GlassRowProps): import("react").JSX.Element;
//# sourceMappingURL=GlassRow.d.ts.map