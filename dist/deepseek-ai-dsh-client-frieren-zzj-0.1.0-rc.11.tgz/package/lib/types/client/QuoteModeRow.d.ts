/**
 * Quote mode row in the Frieren theme section: daily / random / fixed
 * segmented control for the composer dock line, writing the durable
 * `frieren-zzj` settings section.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { QuoteMode } from '../frieren-settings.ts';
/** Registrant-private business face: the quote mode write plus its observable. */
export interface QuoteModeRowInjected {
    /** Persist the quote rotation mode. */
    setQuoteMode: (mode: QuoteMode) => void;
    /** Bare observable of the current quote mode. */
    hooks: {
        quoteMode: {
            getSnapshot(): QuoteMode;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type QuoteModeRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<QuoteModeRowInjected>;
/**
 * Render the quote mode segmented row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function QuoteModeRow({ t, setQuoteMode, useQuoteMode }: QuoteModeRowProps): import("react").JSX.Element;
//# sourceMappingURL=QuoteModeRow.d.ts.map