/**
 * Appearance row in the Frieren theme section: light / dark / system
 * segmented control. Writes through the theme service's own durable
 * `ui-theme` preference namespace, so it stays in sync with the built-in
 * Appearance row in the General section (same source of truth).
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ThemePreference } from '@deepseek-ai/dsh-client-ui-theme/client';
/** Registrant-private business face: the theme preference write plus the live preference observable. */
export interface SchemeRowInjected {
    /** Switch the app theme preference (persisted by the theme service). */
    setScheme: (preference: ThemePreference) => void;
    /** Bare observable of the current theme preference. */
    hooks: {
        scheme: {
            getSnapshot(): ThemePreference;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type SchemeRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<SchemeRowInjected>;
/**
 * Render the appearance segmented row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function SchemeRow({ t, setScheme, useScheme }: SchemeRowProps): import("react").JSX.Element;
//# sourceMappingURL=SchemeRow.d.ts.map