import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { WallpaperVariant } from '../frieren-settings.ts';
/** Registrant-private business face: tone/custom writes plus their observables. */
export interface VariantRowInjected {
    /** Persist the built-in tone variant. */
    setVariant: (variant: WallpaperVariant) => void;
    /** Persist an uploaded image as the custom wallpaper (downscaled data URL). */
    setCustomWallpaper: (dataUrl: string) => void;
    /** Persist the perceived brightness (0..1) sampled from the uploaded image. */
    setCustomBrightness: (brightness: number) => void;
    /** Clear the custom wallpaper and return to the built-in image. */
    clearCustomWallpaper: () => void;
    /** Bare observables of the tone variant and the custom wallpaper data URL. */
    hooks: {
        variant: {
            getSnapshot(): WallpaperVariant;
            subscribe(fn: () => void): () => void;
        };
        customWallpaper: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type VariantRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<VariantRowInjected>;
/**
 * Downscaled JPEG data URL plus perceived brightness (0..1) of an image
 * file. Non-JPEG sources (including transparent PNGs) are flattened onto the
 * JPEG canvas; brightness is sampled on a tiny probe canvas, so uploads of
 * any size cost one cheap getImageData read.
 */
export interface ProcessedUpload {
    /** `data:image/jpeg;base64,…` URL of the downscaled image. */
    dataUrl: string;
    /** Perceived brightness in [0, 1] (Rec. 601 luma weights). */
    brightness: number;
}
/**
 * Load an image file and produce the downscaled JPEG + brightness sample.
 * @param file - the picked image file.
 * @returns the processed upload.
 */
export declare function fileToProcessedUpload(file: File): Promise<ProcessedUpload>;
/**
 * Render the wallpaper tone row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function VariantRow({ t, setVariant, setCustomWallpaper, setCustomBrightness, clearCustomWallpaper, useVariant, useCustomWallpaper, }: VariantRowProps): import("react").JSX.Element;
//# sourceMappingURL=VariantRow.d.ts.map