import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registrant-private business face: the custom-wallpaper write plus its observable. */
export interface WallpaperUploadRowInjected {
    /** Persist an uploaded image as the custom wallpaper (downscaled data URL). */
    setCustomWallpaper: (dataUrl: string) => void;
    /** Clear the custom wallpaper and return to the built-in image. */
    clearCustomWallpaper: () => void;
    /** Bare observable of the custom wallpaper data URL. */
    hooks: {
        customWallpaper: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type WallpaperUploadRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<WallpaperUploadRowInjected>;
/**
 * Render the custom wallpaper row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function WallpaperUploadRow({ t, setCustomWallpaper, clearCustomWallpaper, useCustomWallpaper }: WallpaperUploadRowProps): import("react").JSX.Element;
//# sourceMappingURL=WallpaperUploadRow.d.ts.map