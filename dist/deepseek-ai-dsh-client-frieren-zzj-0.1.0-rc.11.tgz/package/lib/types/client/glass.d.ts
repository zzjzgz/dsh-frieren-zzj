/**
 * Glassmorphism engine: preset templates and the stylesheet generator for
 * the input-card glass layer.
 *
 * Target (stable data attribute owned by ui-conversation's InputBar):
 * - `[data-composer-card]` — the input card itself: frosted card over the
 *   wallpaper/transcript. The composer seat band is NOT glassed, and the
 *   message area stays transparent, so the wallpaper remains fully visible
 *   and the glass region stays exactly card-sized.
 *
 * `backdrop-filter` paints on the element itself, so it is immune to the
 * stacking-context isolation that broke earlier overlay tricks; the input
 * overlays inside the card are `position: absolute` (unaffected by the new
 * containing block) and every fixed-position popover portals to
 * `document.body`, so nothing can be trapped.
 *
 * Dark mode is keyed on `body[data-ds-dark-theme]` (the theme presenter's
 * own switch), so the dark glass params follow the user's manual
 * light/dark/system preference — not the OS media query.
 */
import type { GlassMode, GlassParams } from '../frieren-settings.ts';
import type { FrierenLocaleKey } from './locales.ts';
/** Glass layer base colors (RGB triplets) per mode: lavender parchment / indigo night. */
export declare const GLASS_BASE_RGB: Record<GlassMode, string>;
/** One preset template: fills BOTH modes' params; the user may then fine-tune. */
export interface GlassPreset {
    /** Stable preset id. */
    id: 'clear' | 'frosted' | 'dark';
    /** Locale key for the preset label. */
    labelKey: FrierenLocaleKey;
    /** Light-mode params the preset fills. */
    light: GlassParams;
    /** Dark-mode params the preset fills. */
    dark: GlassParams;
}
/** The three preset templates, in display order. */
export declare const GLASS_PRESETS: readonly GlassPreset[];
/**
 * Generate the glassmorphism stylesheet for the input card, both modes.
 * The card keeps its own shadow; the radius param replaces its built-in
 * 22px rounding.
 * @param light - light-mode params.
 * @param dark - dark-mode params.
 * @returns the stylesheet text (always present while the plugin is composed).
 */
export declare function glassCss(light: GlassParams, dark: GlassParams): string;
//# sourceMappingURL=glass.d.ts.map