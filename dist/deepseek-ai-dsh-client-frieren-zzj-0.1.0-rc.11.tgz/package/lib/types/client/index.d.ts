import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type FrierenLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * One preference row inside the Frieren theme section. Declared at
         * runtime by this plugin's section entry (mirrors the settings domain's
         * 'settings.general.item' contract); the type lives here so the section
         * and its rows can collaborate.
         */
        'settings.frieren.item': {
            kind: 'list';
            scope: 'root';
            owner: {
                children?: never;
            };
        };
    }
    interface LocaleNamespaceMap {
        /** The Frieren theme section and its rows' copy. */
        'settings.frieren': FrierenLocaleKey;
    }
}
/** Required services: the theme registry, the slot system, the settings transport, and the locale registry. */
export declare const inject: string[];
/**
 * Client plugin body: stack the token layer, inject the theme chrome
 * stylesheet, gate the wallpaper stylesheet and the custom-wallpaper override
 * on the user-owned settings, keep the glassmorphism stylesheet live against
 * both modes' params, and register the "Frieren theme" settings section with
 * its six rows. Every side effect is owned by this plugin's fiber and removed
 * on dispose.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map