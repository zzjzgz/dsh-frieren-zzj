/** Locale bundles for the Frieren theme section and its rows. */
/** Locale keys the Frieren theme surface renders. */
export type FrierenLocaleKey = 'section.nav' | 'wallpaper.title' | 'wallpaper.description' | 'wallpaper.on' | 'wallpaper.off' | 'wallpaper.upload.title' | 'wallpaper.upload.description' | 'wallpaper.upload.button' | 'wallpaper.upload.clear' | 'wallpaper.upload.busy' | 'wallpaper.upload.error' | 'scheme.title' | 'scheme.description' | 'scheme.light' | 'scheme.dark' | 'scheme.system' | 'glass.title' | 'glass.description' | 'glass.mode.light' | 'glass.mode.dark' | 'glass.preset.clear' | 'glass.preset.frosted' | 'glass.preset.dark' | 'glass.param.alpha' | 'glass.param.blur' | 'glass.param.border' | 'glass.param.radius' | 'decor.title' | 'decor.description' | 'decor.sparkles' | 'decor.flowers' | 'decor.circle' | 'decor.ribbon' | 'decor.vignette' | 'quote.title' | 'quote.description' | 'quote.daily' | 'quote.random' | 'quote.fixed' | 'quote.series';
/** English copy. */
export declare const en: Record<FrierenLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<FrierenLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map