/**
 * Frieren × Himmel quote library for the composer dock line. Quotes are
 * fan-curated flavor lines from 葬送のフリーレン; the zh/en glosses are
 * fan translations (意译), not official. The dock always renders the Japanese
 * original with a localized attribution; the gloss rides the title tooltip.
 */
import type { QuoteMode } from '../frieren-settings.ts';
/** One quote entry: original Japanese, glosses, and speaker attribution. */
export interface FrierenQuote {
    /** Japanese original line. */
    ja: string;
    /** Simplified Chinese gloss. */
    zh: string;
    /** English gloss. */
    en: string;
    /** Speaker name in Japanese. */
    speakerJa: string;
    /** Speaker name in Chinese. */
    speakerZh: string;
}
/** The curated quote library, in display order; index 0 is the fixed classic line. */
export declare const FRIEREN_QUOTES: readonly FrierenQuote[];
/**
 * Pick one quote for the given mode.
 * @param mode - rotation mode; `fixed` always returns the classic Himmel line.
 * @param now - epoch ms; injectable for determinism in tests.
 * @returns the selected quote.
 */
export declare function pickQuote(mode: QuoteMode, now?: number): FrierenQuote;
//# sourceMappingURL=quotes.d.ts.map