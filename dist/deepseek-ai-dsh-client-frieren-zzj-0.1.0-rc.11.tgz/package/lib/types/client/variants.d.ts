/**
 * Wallpaper tone variants and the overlay stylesheet generator.
 *
 * Tints are applied as body multi-layer backgrounds with
 * `background-blend-mode`: the tint gradient layer and the wallpaper image
 * layer live on the SAME element, so the blend is composited by the element's
 * own painting (no stacking-context / backdrop isolation issues — the
 * previous stage-div + mix-blend-mode approach could silently no-op in some
 * browsers). The overlay stylesheet only overrides `background-image` and
 * `background-blend-mode`; position/size/repeat keep the base rule's values.
 */
import type { WallpaperVariant } from '../frieren-settings.ts';
/** One tone variant: the light-scheme tint gradient and its blend mode. */
export interface WallpaperVariantDef {
    /** Light-scheme tint gradient layer; null = plain image (no overlay). */
    lightLayer: string | null;
    /** Blend mode applied to the tint layer over the image. */
    blend: 'soft-light' | 'multiply' | 'overlay';
}
/** The six built-in tone variants. */
export declare const WALLPAPER_VARIANT_DEFS: Record<WallpaperVariant, WallpaperVariantDef>;
/**
 * Generate the wallpaper overlay stylesheet for one variant + image source.
 * The image source is either the built-in `var(--fri-bg)` or a custom data
 * URL (JPEG base64 — contains no quote characters, safe inside url("…")).
 * The dark rule re-applies the dim layer ahead of the tint, so both modes
 * keep the base rule's dimming behavior.
 * @param variant - the active tone variant.
 * @param image - CSS url()/var() text for the wallpaper image layer.
 * @returns the stylesheet text; empty when no overlay is needed (default
 * variant with the built-in image).
 */
export declare function wallpaperOverlayCss(variant: WallpaperVariant, image: string): string;
//# sourceMappingURL=variants.d.ts.map