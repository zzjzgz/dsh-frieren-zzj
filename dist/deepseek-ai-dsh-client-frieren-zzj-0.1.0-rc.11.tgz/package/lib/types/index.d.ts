/**
 * Frieren × Himmel web theme, node half.
 *
 * The node half owns the plugin's user-facing settings: it registers the
 * `frieren-zzj` settings namespace (the wallpaper switch) so the value is
 * served to the browser half and persisted in the user-settings document.
 * Everything visual lives in the browser half.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Host plugin body — register the wallpaper switch's durable section. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map