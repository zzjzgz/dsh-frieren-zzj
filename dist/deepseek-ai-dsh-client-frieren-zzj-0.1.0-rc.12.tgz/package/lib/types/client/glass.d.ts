/**
 * Input-card glass material — fixed frosted-glass stylesheet.
 *
 * Follows the OceanAvenu Dark Glass method
 * (https://blog.csdn.net/qq_43433246/article/details/162127888): a very
 * low-alpha glass background so the wallpaper shows through, a strong
 * `backdrop-filter` blur, a low-opacity white border, a layered shadow, and
 * generous rounding. Light and dark variants are baked in (dark keeps an
 * even lower alpha and a subtler white border, per the article); the
 * material is fixed — users only choose glass vs plain, nothing is
 * adjustable.
 *
 * Target: `[data-composer-card]` — the input card itself (stable attribute
 * owned by ui-conversation's InputBar). The composer seat band and the
 * message area stay untouched, so the wallpaper remains fully visible.
 * Dark rules ride `body[data-ds-dark-theme]`, so the dark glass follows the
 * user's manual light/dark/system preference, not the OS media query.
 *
 * The input overlays inside the card are `position: absolute` (unaffected by
 * the containing block backdrop-filter creates) and every fixed-position
 * popover portals to `document.body`, so nothing can be trapped.
 */
/** The fixed glass-material stylesheet; injected while inputMaterial = 'glass'. */
export declare const GLASS_CSS = "[data-composer-card] {\n  background: rgba(255, 255, 255, 0.18) !important;\n  -webkit-backdrop-filter: blur(28px) saturate(1.35);\n  backdrop-filter: blur(28px) saturate(1.35) !important;\n  border: 1px solid rgba(255, 255, 255, 0.38) !important;\n  border-radius: 18px !important;\n  box-shadow: var(--dsw-shadow-lv2, 0 8px 24px rgba(20, 22, 50, 0.18)), 0 4px 20px rgba(0, 0, 0, 0.18) !important;\n}\nbody[data-ds-dark-theme] [data-composer-card] {\n  background: rgba(16, 17, 33, 0.12) !important;\n  -webkit-backdrop-filter: blur(40px) saturate(1.2);\n  backdrop-filter: blur(40px) saturate(1.2) !important;\n  border: 1px solid rgba(255, 255, 255, 0.12) !important;\n  border-radius: 18px !important;\n  box-shadow: var(--dsw-shadow-lv2, 0 8px 24px rgba(0, 0, 0, 0.35)), 0 4px 20px rgba(0, 0, 0, 0.30) !important;\n}";
//# sourceMappingURL=glass.d.ts.map