/**
 * Glass material — fixed frosted-glass stylesheet for every chat card.
 *
 * Follows the OceanAvenu Dark Glass method
 * (https://blog.csdn.net/qq_43433246/article/details/162127888): a very
 * low-alpha glass background so the wallpaper shows through, a strong
 * `backdrop-filter` blur, a low-opacity white border, a layered shadow, and
 * generous rounding. Light and dark variants are baked in (dark keeps an
 * even lower alpha and a subtler white border, per the article); the
 * material is fixed — users only choose glass vs plain, nothing is
 * adjustable.
 *
 * Targets — every card of the chat surface (stable data attributes owned by
 * ui-conversation / ui-goal / ui-jobs):
 * - `[data-composer-card]` — the input card (InputBar);
 * - `[data-chat-flow-kind='user'] [data-time-hover-root] > :first-child >
 *   :last-child` — the user bubble (right-aligned capsule inside the
 *   user-row stack; the structural seat is belt-and-braces on top of the
 *   `--dsw-specific-bubble` token fallback in the token layer);
 * - `[data-variant]` — reasoning and command cards (think / others);
 * - `[data-context-injection-body]` — the injected-context card;
 * - `[data-approval-scroll]` — the approval takeover card body;
 * - `[data-queue-dock]` / `[data-testid='todo-panel']` — the queue and todo
 *   dock cards above the composer.
 *
 * The message AREA stays untouched (no container panel), so the wallpaper
 * remains visible through the gaps and through the low-alpha glass itself.
 * `backdrop-filter` paints on each card itself — immune to stacking-context
 * isolation; card-internal overlays are `position: absolute` (unaffected by
 * the containing block) and every fixed-position popover portals to
 * `document.body`, so nothing can be trapped.
 *
 * Dark rules ride `body[data-ds-dark-theme]` (the theme presenter's own
 * switch), so the dark glass follows the user's manual light/dark/system
 * preference — not the OS media query.
 */
/** The fixed glass-material stylesheet; injected while inputMaterial = 'glass'. */
export declare const GLASS_CSS: string;
//# sourceMappingURL=glass.d.ts.map