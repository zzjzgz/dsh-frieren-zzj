/**
 * Input-card glass material — fixed frosted-glass stylesheet.
 *
 * Follows the OceanAvenu Dark Glass method
 * (https://blog.csdn.net/qq_43433246/article/details/162127888): a very
 * low-alpha glass background so the wallpaper shows through, a strong
 * `backdrop-filter` blur, a low-opacity white border, a layered shadow, and
 * generous rounding. Light and dark variants are baked in (dark keeps an
 * even lower alpha and a subtler white border, per the article); the
 * material is fixed — users only choose glass vs plain, nothing is
 * adjustable.
 *
 * Targets (stable data attributes):
 * - `[data-composer-card]` — the input card (ui-conversation InputBar);
 * - `[data-testid='todo-panel']` — the task-list dock card (ui-conversation
 *   TodoPanel; the root element IS the card);
 * - `[data-goal-bar] > :first-child` — the goal dock CARD (ui-goal GoalBar:
 *   `data-goal-bar` sits on the full-width positioning dock, whose only
 *   child is the 36px card, so the glass lands on the card, not the dock
 *   strip).
 *
 * Message-area cards (bubbles, tool cards) are deliberately NOT glassed —
 * they keep their default surfaces, and the message area stays transparent,
 * so the wallpaper remains fully visible.
 *
 * `backdrop-filter` paints on the element itself, so it is immune to the
 * stacking-context isolation that broke earlier overlay tricks; the input
 * overlays inside the card are `position: absolute` (unaffected by the new
 * containing block) and every fixed-position popover portals to
 * `document.body`, so nothing can be trapped.
 *
 * Dark mode is keyed on `body[data-ds-dark-theme]` (the theme presenter's
 * own switch), so the dark glass params follow the user's manual
 * light/dark/system preference — not the OS media query.
 */
/** The fixed glass-material stylesheet; injected while inputMaterial = 'glass'. */
export declare const GLASS_CSS: string;
//# sourceMappingURL=glass.d.ts.map