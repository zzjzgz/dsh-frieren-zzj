/** Locale bundles for the Frieren theme section and its rows. */
/** Locale keys the Frieren theme surface renders. */
export type FrierenLocaleKey = 'section.nav' | 'wallpaper.title' | 'wallpaper.description' | 'wallpaper.on' | 'wallpaper.off' | 'wallpaper.upload.title' | 'wallpaper.upload.description' | 'wallpaper.upload.button' | 'wallpaper.upload.clear' | 'wallpaper.upload.busy' | 'wallpaper.upload.error' | 'scheme.title' | 'scheme.description' | 'scheme.light' | 'scheme.dark' | 'scheme.system' | 'material.title' | 'material.description' | 'material.glass' | 'material.plain' | 'decor.title' | 'decor.description' | 'decor.sparkles' | 'decor.flowers' | 'decor.circle' | 'decor.ribbon' | 'decor.vignette' | 'quote.title' | 'quote.description' | 'quote.daily' | 'quote.random' | 'quote.fixed' | 'quote.series';
/** English copy. */
export declare const en: Record<FrierenLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<FrierenLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map