import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required services: the theme registry and the slot system. */
export declare const inject: string[];
/**
 * Client plugin body: stack the token layer, inject the global stylesheet,
 * and register the decorative slot entries. Every side effect is owned by
 * this plugin's fiber and removed on dispose.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map