import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type FrierenLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The wallpaper switch row's copy. */
        'settings.frieren': FrierenLocaleKey;
    }
}
/** Required services: the theme registry, the slot system, the settings transport, and the locale registry. */
export declare const inject: string[];
/**
 * Client plugin body: stack the token layer, inject the theme chrome
 * stylesheet, gate the wallpaper stylesheet and the decorative stage on the
 * user-owned wallpaper switch, and register the switch row in the General
 * settings section. Every side effect is owned by this plugin's fiber and
 * removed on dispose.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map