/** Locale bundles for the wallpaper switch row in the General settings section. */
/** Locale keys the wallpaper row renders. */
export type FrierenLocaleKey = 'wallpaper.title' | 'wallpaper.description' | 'wallpaper.on' | 'wallpaper.off';
/** English copy. */
export declare const en: Record<FrierenLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<FrierenLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map