import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { WallpaperVariant } from '../frieren-settings.ts';
/** Registrant-private business face: tone/custom writes plus their observables. */
export interface VariantRowInjected {
    /** Persist the built-in tone variant. */
    setVariant: (variant: WallpaperVariant) => void;
    /** Persist an uploaded image as the custom wallpaper (downscaled data URL). */
    setCustomWallpaper: (dataUrl: string) => void;
    /** Clear the custom wallpaper and return to the built-in image. */
    clearCustomWallpaper: () => void;
    /** Bare observables of the tone variant and the custom wallpaper data URL. */
    hooks: {
        variant: {
            getSnapshot(): WallpaperVariant;
            subscribe(fn: () => void): () => void;
        };
        customWallpaper: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type VariantRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<VariantRowInjected>;
/**
 * Render the wallpaper tone row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function VariantRow({ t, setVariant, setCustomWallpaper, clearCustomWallpaper, useVariant, useCustomWallpaper }: VariantRowProps): import("react").JSX.Element;
//# sourceMappingURL=VariantRow.d.ts.map