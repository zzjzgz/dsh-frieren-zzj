/** Locale bundles for the Frieren theme section and its rows. */
/** Locale keys the Frieren theme surface renders. */
export type FrierenLocaleKey = 'section.nav' | 'wallpaper.title' | 'wallpaper.description' | 'wallpaper.on' | 'wallpaper.off' | 'scheme.title' | 'scheme.description' | 'scheme.light' | 'scheme.dark' | 'scheme.system' | 'variant.title' | 'variant.description' | 'variant.default' | 'variant.dusk' | 'variant.night' | 'variant.upload' | 'variant.clear' | 'variant.busy' | 'decor.title' | 'decor.description' | 'decor.sparkles' | 'decor.flowers' | 'decor.circle' | 'decor.ribbon' | 'decor.vignette' | 'quote.title' | 'quote.description' | 'quote.daily' | 'quote.random' | 'quote.fixed' | 'quote.series' | 'upload.error';
/** English copy. */
export declare const en: Record<FrierenLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<FrierenLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map