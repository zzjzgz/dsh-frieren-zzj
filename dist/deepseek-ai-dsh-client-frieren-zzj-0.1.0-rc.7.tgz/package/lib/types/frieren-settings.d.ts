/** Durable settings owned by the Frieren theme plugin. */
import z from '@deepseek-ai/schemastery';
/** Settings namespace owned by the plugin; persisted in the user-settings document. */
export declare const FRIEREN_SETTINGS_NAMESPACE = "frieren-zzj";
/** Master wallpaper switch. */
export declare const WALLPAPER_FIELD = "wallpaper";
/** Built-in wallpaper tone variant. */
export declare const WALLPAPER_VARIANT_FIELD = "wallpaperVariant";
/** User-uploaded custom wallpaper, stored as a downscaled JPEG data URL. */
export declare const CUSTOM_WALLPAPER_FIELD = "customWallpaper";
/** Per-element decoration switches (kept flat so each rides one settings path). */
export declare const DECOR_SPARKLES_FIELD = "decorSparkles";
export declare const DECOR_FLOWERS_FIELD = "decorFlowers";
export declare const DECOR_CIRCLE_FIELD = "decorCircle";
export declare const DECOR_RIBBON_FIELD = "decorRibbon";
export declare const DECOR_VIGNETTE_FIELD = "decorVignette";
/** Quote rotation mode for the composer dock line. */
export declare const QUOTE_MODE_FIELD = "quoteMode";
/** Built-in wallpaper tone variants (pure CSS overlays — zero extra bytes). */
export declare const WALLPAPER_VARIANTS: readonly ["default", "dusk", "night"];
export type WallpaperVariant = typeof WALLPAPER_VARIANTS[number];
/** Quote rotation modes: one per day, random per change, or the fixed classic line. */
export declare const QUOTE_MODES: readonly ["daily", "random", "fixed"];
export type QuoteMode = typeof QUOTE_MODES[number];
/** Defaults mirrored in the schema; reads fall back here while a settings document is absent or stale. */
export declare const DEFAULT_WALLPAPER_VARIANT: WallpaperVariant;
export declare const DEFAULT_QUOTE_MODE: QuoteMode;
/** The five toggleable decoration layers of the wallpaper stage. */
export interface DecorState {
    /** Twinkling gold / periwinkle star specks. */
    sparkles: boolean;
    /** Falling blue moon weed blossoms. */
    flowers: boolean;
    /** Top-right rotating magic circle. */
    circle: boolean;
    /** Top tricolor ribbon. */
    ribbon: boolean;
    /** Corner vignette. */
    vignette: boolean;
}
/** Fully-resolved settings every consumer reads; every field is defined. */
export type ResolvedFrierenSettings = Required<FrierenSettings>;
/** Durable section shared by the Host schema and the browser scope. */
export interface FrierenSettings {
    /** Show the watercolor wallpaper scene; off hides the background image and its stage decorations. */
    wallpaper: boolean;
    /** Built-in wallpaper tone variant. */
    wallpaperVariant: WallpaperVariant;
    /** Custom wallpaper data URL ('' = use the built-in image). */
    customWallpaper: string;
    /** Decoration layer switches (see {@link DecorState}). */
    decorSparkles: boolean;
    decorFlowers: boolean;
    decorCircle: boolean;
    decorRibbon: boolean;
    decorVignette: boolean;
    /** Quote rotation mode for the composer dock line. */
    quoteMode: QuoteMode;
}
/** Durable schema; also the wire envelope the browser scope validates against. */
export declare const FrierenSettingsSchema: z<FrierenSettings>;
/**
 * Narrow one wire value to a persistable wallpaper variant.
 * @param value - value crossing the settings boundary.
 * @returns whether the value is a built-in variant.
 */
export declare function isWallpaperVariant(value: unknown): value is WallpaperVariant;
/**
 * Narrow one wire value to a persistable quote mode.
 * @param value - value crossing the settings boundary.
 * @returns whether the value is a built-in quote mode.
 */
export declare function isQuoteMode(value: unknown): value is QuoteMode;
/**
 * Resolve a possibly-stale or partial settings value into a complete section:
 * the wire envelope validates against the schema but returns the stored value
 * as-is (defaults are not materialized), so every consumer reads through here.
 * @param value - the scope's decoded section, or undefined before first load.
 * @returns the fully-defaulted settings object.
 */
export declare function resolveSettings(value: Partial<FrierenSettings> | undefined): ResolvedFrierenSettings;
//# sourceMappingURL=frieren-settings.d.ts.map