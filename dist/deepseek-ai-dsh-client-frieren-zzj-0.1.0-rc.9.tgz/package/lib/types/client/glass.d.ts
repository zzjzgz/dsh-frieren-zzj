/**
 * Glassmorphism engine: preset templates and the stylesheet generator for
 * the conversation glass layer.
 *
 * Targets (stable data attributes owned by ui-conversation's skeleton):
 * - `[data-conversation-scroll]` — the transcript scroll body (messages +
 *   the composer seat region): one glass pane over the wallpaper.
 * - `[data-composer-seat]` — the sticky composer band: frosted band under
 *   the input card (its own background gradient is replaced).
 *
 * `backdrop-filter` paints on the element itself, so it is immune to the
 * stacking-context isolation that broke earlier overlay tricks; every
 * fixed-position popover in the app portals to `document.body`, so the new
 * containing block these filters create cannot trap a picker/modal.
 *
 * Dark mode is keyed on `body[data-ds-dark-theme]` (the theme presenter's
 * own switch), so the dark glass params follow the user's manual
 * light/dark/system preference — not the OS media query.
 */
import type { GlassMode, GlassParams } from '../frieren-settings.ts';
import type { FrierenLocaleKey } from './locales.ts';
/** Glass layer base colors (RGB triplets) per mode: lavender parchment / indigo night. */
export declare const GLASS_BASE_RGB: Record<GlassMode, string>;
/** One preset template: fills BOTH modes' params; the user may then fine-tune. */
export interface GlassPreset {
    /** Stable preset id. */
    id: 'clear' | 'frosted' | 'dark';
    /** Locale key for the preset label. */
    labelKey: FrierenLocaleKey;
    /** Light-mode params the preset fills. */
    light: GlassParams;
    /** Dark-mode params the preset fills. */
    dark: GlassParams;
}
/** The three preset templates, in display order. */
export declare const GLASS_PRESETS: readonly GlassPreset[];
/**
 * Generate the glassmorphism stylesheet for both modes.
 * @param light - light-mode params.
 * @param dark - dark-mode params.
 * @returns the stylesheet text (always present while the plugin is composed).
 */
export declare function glassCss(light: GlassParams, dark: GlassParams): string;
//# sourceMappingURL=glass.d.ts.map