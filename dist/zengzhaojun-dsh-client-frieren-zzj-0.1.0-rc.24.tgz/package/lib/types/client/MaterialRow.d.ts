/**
 * Input-bar material row in the Frieren theme section: glass / plain
 * segmented choice. Glass applies the fixed frosted treatment (article
 * method, not adjustable); plain restores the default input-card surface.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { InputMaterial } from '../frieren-settings.ts';
/** Registrant-private business face: the material write plus its observable. */
export interface MaterialRowInjected {
    /** Persist the input-bar material. */
    setMaterial: (material: InputMaterial) => void;
    /** Bare observable of the current material. */
    hooks: {
        material: {
            getSnapshot(): InputMaterial;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type MaterialRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<MaterialRowInjected>;
/**
 * Render the input-bar material row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function MaterialRow({ t, setMaterial, useMaterial, useEnabled }: MaterialRowProps): import("react").JSX.Element | null;
//# sourceMappingURL=MaterialRow.d.ts.map