/**
 * Restore-defaults row at the bottom of the Frieren theme section: one click
 * replaces the whole `frieren-zzj` section with the default values (which
 * also re-enables the plugin and drops stale fields from older versions).
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registrant-private business face: the wholesale reset action. */
export interface ResetRowInjected {
    /** Replace the whole settings section with the defaults. */
    resetDefaults: () => void;
}
/** Full component props: runtime share + locale seat + the injected face. */
export type ResetRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<ResetRowInjected>;
/**
 * Render the restore-defaults row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function ResetRow({ t, resetDefaults }: ResetRowProps): import("react").JSX.Element;
//# sourceMappingURL=ResetRow.d.ts.map