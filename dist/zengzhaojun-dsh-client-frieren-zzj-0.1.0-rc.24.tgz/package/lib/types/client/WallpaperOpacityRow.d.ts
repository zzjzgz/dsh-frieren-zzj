/**
 * Wallpaper opacity slider row in the Frieren theme section: a range slider that
 * controls how transparent the wallpaper is (0–100%). The value is persisted as
 * a 0–1 float in the durable `frieren-zzj` settings section; the presentation
 * layer reads it back through the `wallpaperOpacitySource` observable.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registrant-private business face: the opacity write plus its observable. */
export interface WallpaperOpacityRowInjected {
    /** Persist the wallpaper opacity (0–1). */
    setWallpaperOpacity: (opacity: number) => void;
    /** Bare observable of the current wallpaper opacity. */
    hooks: {
        wallpaperOpacity: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type WallpaperOpacityRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<WallpaperOpacityRowInjected>;
/**
 * Render the wallpaper opacity slider row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function WallpaperOpacityRow({ t, setWallpaperOpacity, useWallpaperOpacity, useEnabled }: WallpaperOpacityRowProps): import("react").JSX.Element | null;
//# sourceMappingURL=WallpaperOpacityRow.d.ts.map