/**
 * Wallpaper switch row registered into the Frieren theme settings section:
 * title + description and a toggle that writes the durable `frieren-zzj`
 * settings section. The row reads the same observable the wallpaper
 * presentation is gated on, so its state always mirrors what the page
 * currently shows.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registrant-private business face: the durable write plus the enabled observable. */
export interface WallpaperRowInjected {
    /** Persist the wallpaper switch through the settings scope. */
    setWallpaper: (enabled: boolean) => void;
    /** Bare observable the renderer binds as useWallpaperEnabled. */
    hooks: {
        wallpaperEnabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type WallpaperRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<WallpaperRowInjected>;
/**
 * Render the wallpaper switch row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function WallpaperRow({ t, setWallpaper, useWallpaperEnabled, useEnabled }: WallpaperRowProps): import("react").JSX.Element | null;
//# sourceMappingURL=WallpaperRow.d.ts.map