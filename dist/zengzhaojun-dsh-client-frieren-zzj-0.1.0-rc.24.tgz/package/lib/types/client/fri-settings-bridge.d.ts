/**
 * Browser settings transport for the Frieren theme section.
 *
 * The harness's settings RPC (`settings.describe` / `settings.mutate`)
 * refuses namespaces outside its hardcoded allowlist, so `frieren-zzj` can
 * never cross that seam. Instead this store talks to the plugin's own node
 * half through the same-origin bridge route (`/plugins/<package>/settings`),
 * which proxies straight to the settings service on the host. The surface
 * mirrors the settingsScope contract the presentation code already consumes:
 * a sync snapshot (value + revision), a subscribe/notify pair, and a `set`
 * that applies optimistically and reconciles with the host answer.
 */
import type { FrierenSettings } from '../frieren-settings.ts';
/** One snapshot of the durable section, revision-stamped for consumer caches. */
export interface FriSettingsSnapshot {
    status: 'ready' | 'unavailable';
    value: FrierenSettings | undefined;
    revision: number;
}
/**
 * Local observable store backed by the host settings bridge route. Reads
 * never block activation; writes apply optimistically, then reconcile with
 * the host's answer (or revert by re-reading when the host refuses).
 */
export declare class FriSettingsBridge {
    private readonly listeners;
    private snapshot;
    private started;
    /** @returns the current sync snapshot (stable reference until the next change). */
    getSnapshot(): FriSettingsSnapshot;
    /** Observe snapshot replacements. */
    subscribe(listener: () => void): () => void;
    /** Start the initial host read; safe to call more than once. */
    start(): void;
    /** Drop every subscriber; the fiber is being disposed. */
    dispose(): void;
    /**
     * Write one field through the bridge. The optimistic snapshot renders the
     * change immediately; the host answer replaces it (or a re-read reverts it
     * when the write was refused). Never rejects: the presentation calls this
     * fire-and-forget.
     * @param field - scalar field inside the namespace section.
     * @param value - JSON-shaped value selected by the user.
     */
    set(field: string, value: unknown): Promise<void>;
    /**
     * Replace the whole section through the bridge (the "restore defaults"
     * action). The optimistic snapshot renders immediately; the host answer
     * replaces it (or a re-read reverts when the write was refused). Never
     * rejects.
     * @param section - the complete section to store (unknown fields dropped).
     */
    replace(section: FrierenSettings): Promise<void>;
    private publish;
    private reload;
}
//# sourceMappingURL=fri-settings-bridge.d.ts.map