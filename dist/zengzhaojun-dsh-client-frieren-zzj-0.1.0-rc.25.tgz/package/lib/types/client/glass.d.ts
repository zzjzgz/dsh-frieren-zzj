/**
 * Input-card glass material — iOS-style frosted-glass stylesheet.
 *
 * Follows the iOS glassmorphism design language (see Apple's Human Interface
 * Guidelines and typical glassmorphism references): a semi-transparent white
 * background so the wallpaper shows through, a moderate `backdrop-filter` blur
 * with saturation boost, a translucent white border, a soft directional shadow,
 * and generous rounding. Light and dark variants are baked in (dark uses an
 * even lower-alpha dark base with a subtler white border); the material is
 * fixed — users only choose glass vs plain, nothing is adjustable.
 *
 * Targets (stable data attributes):
 * - `[data-composer-card]` — the input card (ui-conversation InputBar);
 * - `[data-testid='todo-panel']` — the task-list dock card (ui-conversation
 *   TodoPanel; the root element IS the card);
 * - `[data-goal-bar] > :first-child` — the goal dock CARD (ui-goal GoalBar:
 *   `data-goal-bar` sits on the full-width positioning dock, whose only
 *   child is the 36px card, so the glass lands on the card, not the dock
 *   strip).
 *
 * Message-area cards (bubbles, tool cards) are deliberately NOT glassed —
 * they keep their default surfaces, and the message area stays transparent,
 * so the wallpaper remains fully visible.
 *
 * `backdrop-filter` paints on the element itself, so it is immune to the
 * stacking-context isolation that broke earlier overlay tricks; the input
 * overlays inside the card are `position: absolute` (unaffected by the new
 * containing block) and every fixed-position popover portals to
 * `document.body`, so nothing can be trapped.
 *
 * Dark mode is keyed on `body[data-ds-dark-theme]` (the theme presenter's
 * own switch), so the dark glass params follow the user's manual
 * light/dark/system preference — not the OS media query.
 */
/** The fixed iOS-style glass-material stylesheet; injected while inputMaterial = 'glass'. */
export declare const GLASS_CSS: string;
//# sourceMappingURL=glass.d.ts.map