/**
 * Quote mode row in the Frieren theme section: random / fixed segmented
 * control for the composer dock line, plus a custom fixed-quote input and
 * a custom random-quote table editor. Writes the durable `frieren-zzj`
 * settings section.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { QuoteMode } from '../frieren-settings.ts';
import * as React from 'react';
/** Registrant-private business face: the quote mode write plus its observable. */
export interface QuoteModeRowInjected {
    /** Persist the quote rotation mode. */
    setQuoteMode: (mode: QuoteMode) => void;
    /** Persist the custom fixed quote text. */
    setCustomQuote: (text: string) => void;
    /** Persist the custom random quotes as a JSON string. */
    setCustomRandomQuotes: (json: string) => void;
    /** Bare observable of the current quote mode. */
    hooks: {
        quoteMode: {
            getSnapshot(): QuoteMode;
            subscribe(fn: () => void): () => void;
        };
        customQuote: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
        customRandomQuotes: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type QuoteModeRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<QuoteModeRowInjected>;
/**
 * Render the quote mode segmented row with custom quote editors.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function QuoteModeRow({ t, setQuoteMode, setCustomQuote, setCustomRandomQuotes, useQuoteMode, useCustomQuote, useCustomRandomQuotes, useEnabled }: QuoteModeRowProps): React.JSX.Element | null;
//# sourceMappingURL=QuoteModeRow.d.ts.map