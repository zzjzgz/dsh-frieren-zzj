import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type FrierenLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * One preference row inside the Frieren theme section. Declared at
         * runtime by this plugin's section entry (mirrors the settings domain's
         * 'settings.general.item' contract); the type lives here so the section
         * and its rows can collaborate.
         */
        'settings.frieren.item': {
            kind: 'list';
            scope: 'root';
            owner: {
                children?: never;
            };
        };
    }
    interface LocaleNamespaceMap {
        /** The Frieren theme section and its rows' copy. */
        'settings.frieren': FrierenLocaleKey;
    }
}
/** Required services: the theme registry, the slot system, and the locale registry. */
export declare const inject: string[];
/**
 * Client plugin body: gate every effect (theme chrome stylesheet, wallpaper
 * stylesheet, custom-wallpaper override, input-card material, decorative stage,
 * seal, badge, dock quote) on the user-owned `enabled` master switch plus their
 * individual settings, and register the "Frieren theme" settings section with
 * its rows (master switch, appearance, upload, material, decorations, quote
 * mode with custom quote support, restore defaults). Every side effect is owned
 * by this plugin's fiber and removed on dispose.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map