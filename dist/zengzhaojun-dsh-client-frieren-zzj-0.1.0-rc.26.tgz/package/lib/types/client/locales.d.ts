/** Locale bundles for the Frieren theme section and its rows. */
/** Locale keys the Frieren theme surface renders. */
export type FrierenLocaleKey = 'section.nav' | 'enable.title' | 'enable.description' | 'enable.on' | 'enable.off' | 'reset.title' | 'reset.description' | 'reset.button' | 'wallpaper.upload.title' | 'wallpaper.upload.description' | 'wallpaper.upload.button' | 'wallpaper.upload.clear' | 'wallpaper.upload.busy' | 'wallpaper.upload.error' | 'scheme.title' | 'scheme.description' | 'scheme.light' | 'scheme.dark' | 'scheme.system' | 'material.title' | 'material.description' | 'material.glass' | 'material.plain' | 'decor.title' | 'decor.description' | 'decor.sparkles' | 'decor.flowers' | 'decor.circle' | 'decor.ribbon' | 'decor.vignette' | 'quote.title' | 'quote.description' | 'quote.random' | 'quote.fixed' | 'quote.series' | 'quote.custom.title' | 'quote.custom.description' | 'quote.custom.placeholder' | 'quote.randomTable.title' | 'quote.randomTable.description' | 'quote.randomTable.textHeader' | 'quote.randomTable.speakerHeader' | 'quote.randomTable.glossHeader' | 'quote.randomTable.addRow' | 'quote.randomTable.deleteRow' | 'quote.randomTable.empty';
/** English copy. */
export declare const en: Record<FrierenLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<FrierenLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map