/**
 * Frieren × Himmel quote library for the composer dock line. Quotes are
 * fan-curated flavor lines from 葬送のフリーレン; the zh/en glosses are
 * fan translations (意译), not official. The dock always renders the Japanese
 * original with a localized attribution; the gloss rides the title tooltip.
 *
 * Supports custom quotes: a user-supplied fixed line overrides the built-in
 * classic Himmel line, and a user-supplied list feeds the random mode.
 */
import type { CustomQuoteEntry } from '../frieren-settings.ts';
/** One quote entry: original Japanese, glosses, and speaker attribution. */
export interface FrierenQuote {
    /** Japanese original line. */
    ja: string;
    /** Simplified Chinese gloss. */
    zh: string;
    /** English gloss. */
    en: string;
    /** Speaker name in Japanese. */
    speakerJa: string;
    /** Speaker name in Chinese. */
    speakerZh: string;
}
/** The curated quote library, in display order; index 0 is the fixed classic line. */
export declare const FRIEREN_QUOTES: readonly FrierenQuote[];
/**
 * Pick one quote for the given mode, honoring user-supplied overrides.
 * @param mode - rotation mode; `fixed` returns the custom or built-in classic line.
 * @param customQuote - user-supplied fixed quote text (empty = built-in).
 * @param customQuotes - user-supplied random list (empty = built-in library).
 * @returns the selected quote.
 */
export declare function pickQuote(mode: 'random' | 'fixed', customQuote?: string, customQuotes?: readonly CustomQuoteEntry[]): FrierenQuote;
//# sourceMappingURL=quotes.d.ts.map