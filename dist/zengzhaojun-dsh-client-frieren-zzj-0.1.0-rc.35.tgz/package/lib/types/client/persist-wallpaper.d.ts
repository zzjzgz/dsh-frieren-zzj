/** Minimal fetch surface, injectable so the fallbacks are unit-testable. */
export type FetchLike = (input: string, init?: {
    method?: string;
    headers?: Record<string, string>;
    body?: string;
}) => Promise<{
    ok: boolean;
    json: () => Promise<unknown>;
}>;
/**
 * Store one wallpaper image, preferring the file store.
 * @param dataUrl - the downscaled `data:image/jpeg;base64,…` image.
 * @param request - fetch implementation (defaults to the global fetch).
 * @returns the URL to persist: a store URL on success, otherwise `dataUrl`.
 */
export declare function persistWallpaper(dataUrl: string, request?: FetchLike): Promise<string>;
//# sourceMappingURL=persist-wallpaper.d.ts.map