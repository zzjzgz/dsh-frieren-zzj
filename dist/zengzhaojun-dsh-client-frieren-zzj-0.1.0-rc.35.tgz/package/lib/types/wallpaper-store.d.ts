/** Largest upload the store accepts, in bytes. */
export declare const MAX_WALLPAPER_BYTES: number;
/** How long an unreferenced file is spared, in milliseconds. */
export declare const PRUNE_GRACE_MS: number;
/**
 * Content address of one image.
 * @param bytes - the image payload.
 * @returns the first 32 hex characters of its SHA-256 digest.
 */
export declare function wallpaperId(bytes: Uint8Array): string;
/**
 * File name for one content address.
 * @param id - a {@link wallpaperId} result.
 * @returns the on-disk file name.
 */
export declare function wallpaperFileName(id: string): string;
/**
 * Whether a directory entry is a file this store owns.
 * @param name - directory entry name.
 * @returns true only for well-formed wallpaper file names.
 */
export declare function isWallpaperFileName(name: string): boolean;
/**
 * Extract the requested file name from a route URL.
 * @param url - the raw request URL (path plus optional query).
 * @returns the file name, or undefined when the request does not address one.
 */
export declare function parseWallpaperRequest(url: string | undefined): string | undefined;
/**
 * Decode one upload body into image bytes.
 * @param body - the parsed request body's `dataUrl` value.
 * @param maxBytes - size ceiling, injectable for tests.
 * @returns the decoded bytes, or undefined when the body is not a supported
 * image data URL within the ceiling.
 */
export declare function decodeWallpaperUpload(body: unknown, maxBytes?: number): Uint8Array | undefined;
/**
 * Write one image into the store directory.
 * @param directory - store directory (created when missing).
 * @param bytes - the image payload.
 * @returns the stored file name; an identical image already stored is kept.
 */
export declare function storeWallpaper(directory: string, bytes: Uint8Array): Promise<string>;
/**
 * Read one stored image.
 * @param directory - store directory.
 * @param name - requested file name (validated before any path is built).
 * @returns the bytes, or undefined when the name is not a store file or the
 * file is gone.
 */
export declare function loadWallpaper(directory: string, name: string): Promise<Uint8Array | undefined>;
/**
 * Which stored files the settings still reference.
 *
 * This decides what a prune is allowed to delete, so it is strict on purpose:
 * only a `…/<name>` tail matching {@link isWallpaperFileName} counts. Legacy
 * inline data URLs — which contain slashes inside their own payload — and any
 * other stray string simply reference nothing.
 * @param customWallpapers - the stored gallery JSON (array of URLs).
 * @returns the file names in use.
 */
export declare function referencedWallpaperNames(customWallpapers: unknown): Set<string>;
/**
 * Whether a stored file may be deleted because nothing references it.
 * @param name - directory entry name.
 * @param referenced - file names the current settings still use.
 * @param mtimeMs - the file's modification time.
 * @param nowMs - the current time.
 * @returns true only for an unreferenced wallpaper file past the grace window.
 */
export declare function pruneableWallpaper(name: string, referenced: ReadonlySet<string>, mtimeMs: number, nowMs: number): boolean;
//# sourceMappingURL=wallpaper-store.d.ts.map