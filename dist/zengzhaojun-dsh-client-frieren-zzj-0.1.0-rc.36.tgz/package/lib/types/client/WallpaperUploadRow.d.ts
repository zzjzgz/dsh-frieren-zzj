import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registrant-private business face: the gallery writes plus their observables. */
export interface WallpaperUploadRowInjected {
    /** Persist the whole gallery (replaces the list and clears the legacy field). */
    setGallery: (list: readonly string[]) => void;
    /** Clear the gallery and the legacy single-wallpaper field. */
    clearGallery: () => void;
    /** Persist the wallpaper blur radius in px (0-20). */
    setWallpaperBlur: (blur: number) => void;
    /** Persist the wallpaper dim percentage (0-80). */
    setWallpaperDim: (dim: number) => void;
    /** Bare observables of the gallery, the legacy image, and the master switch. */
    hooks: {
        customWallpaper: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
        customWallpapers: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
        wallpaperBlur: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        wallpaperDim: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type WallpaperUploadRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<WallpaperUploadRowInjected>;
/**
 * Render the wallpaper gallery row with upload, thumbnails, per-image removal,
 * clear-all, and the blur and dim sliders.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function WallpaperUploadRow({ t, setGallery, clearGallery, setWallpaperBlur, setWallpaperDim, useCustomWallpaper, useCustomWallpapers, useWallpaperBlur, useWallpaperDim, useEnabled }: WallpaperUploadRowProps): import("react").JSX.Element | null;
//# sourceMappingURL=WallpaperUploadRow.d.ts.map