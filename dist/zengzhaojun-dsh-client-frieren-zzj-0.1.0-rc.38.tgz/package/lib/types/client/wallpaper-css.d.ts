/**
 * Compose the wallpaper layer's `background-image` value: the uploaded image
 * with an optional darkening gradient stacked on top for text readability.
 * The dim percentage is clamped to 0–80; 0 produces the bare `url(...)` so the
 * no-dim rendering stays byte-identical to the pre-feature behavior.
 * @param custom - the wallpaper image URL (data URL); empty yields ''.
 * @param dim - requested dim percentage (0–80, out-of-range clamped).
 * @returns the CSS `background-image` value.
 */
export declare function wallpaperLayerBackground(custom: string, dim: number): string;
//# sourceMappingURL=wallpaper-css.d.ts.map