import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { FrierenSettings, ResolvedFrierenSettings } from '../frieren-settings.ts';
/** Registrant-private business face: settings read/write for the backup row. */
export interface BackupRowInjected {
    /** Read the current resolved settings at click time (never a stale prop). */
    readSettings: () => ResolvedFrierenSettings;
    /** Merge validated fields over the current settings. */
    importSettings: (value: Partial<FrierenSettings>) => void;
    /** Bare observable of the master switch. */
    hooks: {
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type BackupRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<BackupRowInjected>;
/**
 * Render the export/import row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function BackupRow({ t, readSettings, importSettings, useEnabled }: BackupRowProps): import("react").JSX.Element | null;
//# sourceMappingURL=BackupRow.d.ts.map