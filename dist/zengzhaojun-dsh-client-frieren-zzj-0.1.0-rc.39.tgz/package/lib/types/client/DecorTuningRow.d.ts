import * as React from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registrant-private business face: the tuning writes plus their observables. */
export interface DecorTuningRowInjected {
    /** Persist the element density multiplier. */
    setDensity: (value: number) => void;
    /** Persist the animation speed multiplier. */
    setSpeed: (value: number) => void;
    /** Persist the magic-circle scale multiplier. */
    setCircleScale: (value: number) => void;
    /** Bare observables of the three tuning values plus the master switch. */
    hooks: {
        density: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        speed: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        circleScale: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type DecorTuningRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<DecorTuningRowInjected>;
/**
 * Render the decoration tuning row: density, speed, and magic-circle scale.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function DecorTuningRow({ t, setDensity, setSpeed, setCircleScale, useDensity, useSpeed, useCircleScale, useEnabled }: DecorTuningRowProps): React.JSX.Element | null;
//# sourceMappingURL=DecorTuningRow.d.ts.map