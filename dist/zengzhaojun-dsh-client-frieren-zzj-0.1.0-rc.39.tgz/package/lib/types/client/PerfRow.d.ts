/**
 * Performance-tier row in the Frieren theme section: one click sets the
 * decoration density, the animation speed, and the material together, so a
 * weak GPU or a drained battery needs no slider-by-slider tuning. The row
 * highlights the tier the current values correspond to, and shows nothing
 * pressed once any of the three has been hand-tuned (a "custom" state).
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { InputMaterial } from '../frieren-settings.ts';
import { type PerfTier } from './perf-tier.ts';
/** Registrant-private business face: the tier write plus the live values. */
export interface PerfRowInjected {
    /** Apply one tier (density, speed, and material in one go). */
    setTier: (tier: PerfTier) => void;
    /** Bare observables of the values a tier writes plus the master switch. */
    hooks: {
        density: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        speed: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        material: {
            getSnapshot(): InputMaterial;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type PerfRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<PerfRowInjected>;
/**
 * Render the performance-tier row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function PerfRow({ t, setTier, useDensity, useSpeed, useMaterial, useEnabled }: PerfRowProps): import("react").JSX.Element | null;
//# sourceMappingURL=PerfRow.d.ts.map