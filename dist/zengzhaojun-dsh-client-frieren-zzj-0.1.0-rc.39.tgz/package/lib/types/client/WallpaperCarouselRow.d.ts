import * as React from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type WallpaperRotation } from '../frieren-settings.ts';
/** Registrant-private business face: the rotation writes plus their observables. */
export interface WallpaperCarouselRowInjected {
    /** Persist the rotation interval in seconds. */
    setInterval: (seconds: number) => void;
    /** Persist the rotation order. */
    setMode: (mode: WallpaperRotation) => void;
    /** Bare observables of the gallery, the legacy single image, and the master switch. */
    hooks: {
        gallery: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
        single: {
            getSnapshot(): string;
            subscribe(fn: () => void): () => void;
        };
        interval: {
            getSnapshot(): number;
            subscribe(fn: () => void): () => void;
        };
        mode: {
            getSnapshot(): WallpaperRotation;
            subscribe(fn: () => void): () => void;
        };
        enabled: {
            getSnapshot(): boolean;
            subscribe(fn: () => void): () => void;
        };
    };
}
/** Full component props: runtime share + locale seat + the injected face. */
export type WallpaperCarouselRowProps = PropsRuntime<'settings.frieren.item'> & PropsLocale<'settings.frieren'> & InjectFace<WallpaperCarouselRowInjected>;
/**
 * Render the gallery rotation row.
 * @param props - composed slot props.
 * @returns the row element tree, or null for a gallery of fewer than two images.
 */
export declare function WallpaperCarouselRow({ t, setInterval, setMode, useGallery, useSingle, useInterval, useMode, useEnabled }: WallpaperCarouselRowProps): React.ReactElement | null;
//# sourceMappingURL=WallpaperCarouselRow.d.ts.map