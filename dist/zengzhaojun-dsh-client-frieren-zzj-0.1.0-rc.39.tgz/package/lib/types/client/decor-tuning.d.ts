/**
 * Pure decoration-tuning math: how many sparkles/blossoms a density keeps, how
 * evenly they spread, and how a speed multiplier maps onto animation
 * durations. Kept free of DOM and React imports so the math is unit-testable
 * under `node --test`.
 */
/** Lowest density the slider offers (a quarter of the decorations). */
export declare const MIN_DECOR_DENSITY = 0.25;
/** Highest density the slider offers (the full set). */
export declare const MAX_DECOR_DENSITY = 2;
/** Slowest animation speed multiplier the slider offers. */
export declare const MIN_DECOR_SPEED = 0.25;
/** Fastest animation speed multiplier the slider offers. */
export declare const MAX_DECOR_SPEED = 4;
/** Smallest magic-circle scale the slider offers. */
export declare const MIN_CIRCLE_SCALE = 0.5;
/** Largest magic-circle scale the slider offers. */
export declare const MAX_CIRCLE_SCALE = 2;
/**
 * Clamp one tuning value into its slider range.
 * @param value - requested value.
 * @param min - inclusive lower bound.
 * @param max - inclusive upper bound.
 * @returns the clamped value.
 */
export declare function clampTuning(value: number, min: number, max: number): number;
/**
 * How many decorations of a full set a density keeps.
 * @param total - size of the full decoration set.
 * @param density - density multiplier (clamped into range).
 * @returns at least 1 and never more than `total`; 0 for an empty set.
 */
export declare function pickDecorCount(total: number, density: number): number;
/**
 * Select an evenly spread subset of a decoration set, so a lower density
 * thins the scene across the whole viewport instead of trimming one side.
 * @param items - the full ordered set (ordered by position).
 * @param density - density multiplier (clamped into range).
 * @returns the selected items, in the original order.
 */
export declare function pickDecorSubset<T>(items: readonly T[], density: number): T[];
/**
 * Map a speed multiplier onto an animation duration: speed 2 runs twice as
 * fast, i.e. half the duration.
 * @param baseSeconds - the decoration's nominal duration in seconds.
 * @param speed - speed multiplier (clamped into range).
 * @returns the scaled duration in seconds.
 */
export declare function scaleDuration(baseSeconds: number, speed: number): number;
//# sourceMappingURL=decor-tuning.d.ts.map