/**
 * iOS-style frosted-glass material stylesheet — applied to input cards AND
 * the settings panel.
 *
 * Follows the iOS glassmorphism design language (see Apple's Human Interface
 * Guidelines and typical glassmorphism references): a semi-transparent white
 * background so the wallpaper shows through, a moderate `backdrop-filter` blur
 * with saturation boost, a translucent white border, a soft directional shadow,
 * and generous rounding. Light and dark variants are baked in (dark uses an
 * even lower-alpha dark base with a subtler white border); the material is
 * fixed — users only choose glass vs plain, nothing is adjustable.
 *
 * The light variant's white is deliberately strong (0.62). Glass here is a
 * TEXT surface: light-palette ink is near-black, and 0.25 white over a dark
 * wallpaper leaves the settings modal and the composer at ~2:1 contrast, i.e.
 * unreadable. At 0.62 the surface stays above 4.5:1 even over a black
 * wallpaper, and over the default white page it renders white either way, so
 * nothing changes until a wallpaper is actually behind it. These cards are the
 * only glassed surfaces — the message area itself keeps its own surface.
 *
 * Targets (stable selectors):
 * - `[data-composer-card]` — the input card (ui-conversation InputBar);
 * - `[data-testid='todo-panel']` — the task-list dock card (ui-conversation
 *   TodoPanel; the root element IS the card);
 * - `[data-goal-bar] > :first-child` — the goal dock CARD (ui-goal GoalBar:
 *   `data-goal-bar` sits on the full-width positioning dock, whose only
 *   child is the 36px card, so the glass lands on the card, not the dock
 *   strip).
 * - `[role="dialog"][aria-modal="true"]` — the settings modal panel
 *   (ui-settings-general SettingsRoot: the centered 800px panel that
 *   contains every settings section).
 *
 * Message-area cards (bubbles, tool cards) are deliberately NOT glassed —
 * they keep their default surfaces, and the message area stays transparent,
 * so the wallpaper remains fully visible.
 *
 * `backdrop-filter` paints on the element itself, so it is immune to the
 * stacking-context isolation that broke earlier overlay tricks; the input
 * overlays inside the card are `position: absolute` (unaffected by the new
 * containing block) and every fixed-position popover portals to
 * `document.body`, so nothing can be trapped.
 *
 * Dark mode is keyed on `body[data-ds-dark-theme]` (the theme presenter's
 * own switch), so the dark glass params follow the user's manual
 * light/dark/system preference — not the OS media query.
 */
/** The fixed iOS-style glass-material stylesheet; injected while inputMaterial = 'glass'. */
export declare const GLASS_CSS: string;
//# sourceMappingURL=glass.d.ts.map