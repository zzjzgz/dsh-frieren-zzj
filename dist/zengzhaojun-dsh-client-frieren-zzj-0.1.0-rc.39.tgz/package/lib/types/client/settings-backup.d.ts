/**
 * Pure (de)serialization for the theme-settings backup file: export writes a
 * stable JSON document, import validates one field at a time so a hand-edited
 * or stale file can never crash the settings section. Free of DOM and React
 * imports so the validation is unit-testable under `node --test`.
 */
import { type FrierenSettings, type ResolvedFrierenSettings } from '../frieren-settings.ts';
/** Import outcome: the fields to apply plus the keys that were left out. */
export interface SettingsImportOk {
    ok: true;
    /** Validated fields, ready to merge over the current settings. */
    value: Partial<FrierenSettings>;
    /** Keys dropped because they are unknown or carry the wrong type. */
    skipped: string[];
}
/** Why a backup document could not be applied (localized by the row). */
export type SettingsImportErrorCode = 'invalid-json' | 'not-an-object' | 'no-fields';
/** Import failure: nothing to apply. */
export interface SettingsImportError {
    ok: false;
    /** Machine-readable reason; the row localizes it. */
    error: SettingsImportErrorCode;
}
/**
 * Serialize the current settings into the backup document.
 * @param settings - the fully-resolved settings section.
 * @returns pretty-printed JSON, stable in key order.
 */
export declare function serializeSettingsBackup(settings: ResolvedFrierenSettings): string;
/**
 * Parse and validate a backup document.
 * @param json - the file's text.
 * @returns either the validated fields (with the dropped keys) or an error.
 */
export declare function parseSettingsBackup(json: string): SettingsImportOk | SettingsImportError;
//# sourceMappingURL=settings-backup.d.ts.map