/** Collaborators the flow drives; every one is injected so tests can falsify them. */
export interface WallpaperAddPorts {
    /** Downscale the picked file into a data URL. */
    encode: () => Promise<string>;
    /** Hand the image to the file store, returning the URL to persist. */
    store: (dataUrl: string) => Promise<string>;
    /** The gallery as it stands right now (fresh read, not a render-scope value). */
    readGallery: () => readonly string[];
    /** Persist the gallery the entry was added to. */
    commit: (next: readonly string[]) => void;
    /** Delete files whose last reference an edit removed (best effort). */
    forget: (names: readonly string[]) => void;
    /** Gallery capacity; defaults to {@link MAX_WALLPAPERS}. */
    max?: number;
}
/** What one pick did. */
export type WallpaperAddResult = 
/** The image was stored and appended to the gallery. */
'added'
/** The gallery had no room; nothing was uploaded. */
 | 'full'
/** Reading or storing the image failed; the gallery is untouched. */
 | 'failed';
/**
 * Add one picked image to the wallpaper gallery.
 * @param ports - the collaborators this flow drives.
 * @returns the outcome, so the caller can render the matching message.
 */
export declare function addWallpaper(ports: WallpaperAddPorts): Promise<WallpaperAddResult>;
//# sourceMappingURL=wallpaper-add.d.ts.map