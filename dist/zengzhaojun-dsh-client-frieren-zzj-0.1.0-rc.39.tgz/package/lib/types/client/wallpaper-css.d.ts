/**
 * Custom property carrying the veil color as an `R, G, B` triple. The layer's
 * inline `background-image` reads it, so a single declaration flips the veil
 * with the palette without repainting the layer: the dark palette shades the
 * wallpaper black, the light palette mists it white.
 */
export declare const WALLPAPER_SCRIM_RGB_VARIABLE = "--fri-wallpaper-scrim-rgb";
/**
 * Compose the wallpaper layer's `background-image` value: the uploaded image
 * with an optional veil stacked on top for text readability. The dim
 * percentage is clamped to 0–80; 0 produces the bare `url(...)` so the
 * no-veil rendering stays byte-identical to the pre-veil behavior.
 *
 * The veil's COLOR is not baked in: the gradient reads
 * {@link WALLPAPER_SCRIM_RGB_VARIABLE}, which the transparency sheet binds per
 * palette (black under the dark theme, white under the light one). Shading the
 * wallpaper dark under a light palette was the light-theme readability bug:
 * the palette's ink is near-black, so darkening the background pushed the
 * foreground INTO the background. A veil must always move the wallpaper toward
 * the theme's ink, never away from it.
 * @param custom - the wallpaper image URL (data URL); empty yields ''.
 * @param dim - requested veil strength (0–80, out-of-range clamped).
 * @returns the CSS `background-image` value.
 */
export declare function wallpaperLayerBackground(custom: string, dim: number): string;
/**
 * Transparency sheet injected while a wallpaper is painted. The app frame
 * paints an opaque `--dsw-alias-bg-base` (and an opaque sidebar fill), which
 * would hide a layer behind it entirely, so the `data-frieren-wallpaper` body
 * attribute makes those surfaces see-through.
 *
 * Every surface that carries text keeps a palette-appropriate base instead of
 * going fully transparent:
 *
 * - the veil is white under the light palette (see
 *   {@link wallpaperLayerBackground}), so the wallpaper is misted toward the
 *   near-black light ink rather than shaded away from it;
 * - the sidebar fill, the input card, and the message bubbles are re-bound to
 *   a strong translucent white in the light palette. Their defaults in that
 *   palette are near-white (`#f9fafb`, `#fff`, `#edf3fe`), so a fully
 *   transparent surface would drop near-black text straight onto the wallpaper
 *   and leave it unreadable on any dark image — at 62% white the text keeps
 *   its contrast even against a black one. The dark palette's values are
 *   untouched.
 */
export declare const WALLPAPER_TRANSPARENCY_CSS = "\nbody[data-frieren-wallpaper] {\n  --dsw-alias-bg-base: transparent;\n  --dsw-specific-sidebar-fill: transparent;\n  --dsw-specific-input-major: rgba(255, 255, 255, 0.15);\n  --dsw-specific-bubble: rgba(255, 255, 255, 0.12);\n  --fri-wallpaper-scrim-rgb: 0, 0, 0;\n}\nbody[data-frieren-wallpaper]:not([data-ds-dark-theme]) {\n  --fri-wallpaper-scrim-rgb: 255, 255, 255;\n  --dsw-specific-sidebar-fill: rgba(255, 255, 255, 0.62);\n  --dsw-specific-input-major: rgba(255, 255, 255, 0.62);\n  --dsw-specific-bubble: rgba(255, 255, 255, 0.62);\n}\nbody[data-ds-dark-theme][data-frieren-wallpaper] {\n  --dsw-specific-input-major: rgba(255, 255, 255, 0.06);\n  --dsw-specific-bubble: rgba(255, 255, 255, 0.05);\n}\n";
//# sourceMappingURL=wallpaper-css.d.ts.map