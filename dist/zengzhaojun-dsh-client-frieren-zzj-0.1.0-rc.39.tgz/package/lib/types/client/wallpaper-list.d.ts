/**
 * Pure wallpaper-gallery logic: parsing the stored rotation list, resolving it
 * against the legacy single-wallpaper field, and choosing the next image. Kept
 * free of DOM and React imports so the math is unit-testable under
 * `node --test`.
 *
 * Storage note: rotation entries live in the settings document as data URLs
 * (one JSON array field), so the list is capped — every entry is a compressed
 * 1920px JPEG and the settings bridge refuses bodies beyond a few megabytes.
 */
import { type WallpaperRotation } from '../frieren-settings.ts';
/**
 * Clamp a rotation interval into its slider range.
 * @param seconds - requested interval in seconds.
 * @returns the clamped interval, or the default when the value is not a number.
 */
export declare function clampInterval(seconds: number): number;
/**
 * Parse the stored rotation list.
 * @param json - the stored JSON string (array of data URLs).
 * @returns the valid entries in order, capped at {@link MAX_WALLPAPERS}.
 */
export declare function parseWallpaperList(json: string): string[];
/**
 * The effective gallery for the current settings: the rotation list when it has
 * entries, otherwise the legacy single-wallpaper field.
 * @param single - the legacy `customWallpaper` data URL ('' = none).
 * @param json - the stored rotation list JSON.
 * @returns the ordered images to rotate through (empty = no wallpaper).
 */
export declare function resolveWallpaperList(single: string, json: string): string[];
/**
 * Encode a gallery for storage.
 * @param list - the images to store.
 * @returns JSON for the settings document; '' for an empty gallery.
 */
export declare function encodeWallpaperList(list: readonly string[]): string;
/**
 * Choose the image to show next.
 * @param current - index currently displayed (may be out of range).
 * @param length - gallery size.
 * @param rotation - rotation order.
 * @param rng - deterministic random source for tests; defaults to Math.random.
 * @returns the next index; 0 for a gallery of fewer than two images.
 */
export declare function nextWallpaperIndex(current: number, length: number, rotation: WallpaperRotation, rng?: () => number): number;
//# sourceMappingURL=wallpaper-list.d.ts.map