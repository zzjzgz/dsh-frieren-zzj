/**
 * Whether a directory entry is a file this store owns.
 * @param name - directory entry name.
 * @returns true only for well-formed wallpaper file names.
 */
export declare function isWallpaperFileName(name: string): boolean;
/**
 * The file name one gallery entry points at.
 * @param url - a gallery entry (store URL, or a legacy inline data URL).
 * @returns the file name, or undefined for anything that is not a store URL.
 */
export declare function wallpaperNameFromUrl(url: string): string | undefined;
/**
 * The URL a stored file is deleted through.
 * @param name - a validated wallpaper file name.
 * @returns the same-origin URL the browser half sends `DELETE` to.
 */
export declare function wallpaperDeleteUrl(name: string): string;
/**
 * Which stored files a gallery edit orphans.
 *
 * Entries are content-addressed, so the same file can back two gallery slots:
 * a file is dropped only when the new gallery references it nowhere. Inline
 * data URLs are ignored — they have no file behind them.
 * @param previous - the gallery before the edit.
 * @param next - the gallery after the edit.
 * @returns the file names to delete, deduplicated, in first-seen order.
 */
export declare function wallpaperFilesToDelete(previous: readonly string[], next: readonly string[]): string[];
/**
 * Extract the requested file name from a route URL.
 * @param url - the raw request URL (path plus optional query).
 * @returns the file name, or undefined when the request does not address one.
 */
export declare function parseWallpaperRequest(url: string | undefined): string | undefined;
//# sourceMappingURL=wallpaper-names.d.ts.map