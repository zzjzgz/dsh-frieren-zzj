/**
 * Custom property carrying the veil color as an `R, G, B` triple. The veil
 * layer reads it, so a single declaration flips the veil with the palette
 * without repainting anything: the dark palette shades the wallpaper black, the
 * light palette mists it white.
 */
export declare const WALLPAPER_SCRIM_RGB_VARIABLE = "--fri-wallpaper-scrim-rgb";
/** Veil fill: whichever triple the active palette binds. */
export declare const WALLPAPER_VEIL_BACKGROUND = "rgb(var(--fri-wallpaper-scrim-rgb, 0, 0, 0))";
/**
 * Inline CSS of one image layer: full-viewport, cover-fit, resting at the scale
 * the fly-through lands on so an animation can end on its own end frame without
 * a jump. No `background-attachment`, deliberately: it would anchor the
 * background to the viewport and force a re-rasterization per animation frame
 * instead of letting the layer composite. The caller adds `background-image`
 * and `z-index` per paint.
 */
export declare const WALLPAPER_LAYER_STYLE = "position:fixed;inset:0;overflow:hidden;pointer-events:none;background-position:center;background-size:cover;background-repeat:no-repeat;transform:scale(1.1);transition:filter 0.3s ease;";
/** Inline CSS of the veil layer, stacked above both image layers. */
export declare const WALLPAPER_VEIL_STYLE = "position:fixed;inset:0;overflow:hidden;pointer-events:none;background:rgb(var(--fri-wallpaper-scrim-rgb, 0, 0, 0));transition:opacity 0.3s ease;";
/**
 * The `background-image` value of an image layer. Only the picture: the veil is
 * its own layer (see the module doc), and the dim percentage never reaches this
 * string, so changing the dim cannot invalidate a running animation.
 * @param custom - the wallpaper image URL; empty yields '' (no paint).
 * @returns the CSS `background-image` value.
 */
export declare function wallpaperLayerImage(custom: string): string;
/**
 * Translate the stored dim percentage into the veil layer's opacity. Clamped to
 * the settings ceiling so a hand-edited document cannot veil past 80%.
 * @param dim - requested veil strength (0–80, out-of-range clamped).
 * @returns the opacity to write on the veil layer (0–0.8).
 */
export declare function wallpaperVeilOpacity(dim: number): number;
/**
 * Transparency sheet injected while a wallpaper is painted. The app frame
 * paints an opaque `--dsw-alias-bg-base` (and an opaque sidebar fill), which
 * would hide the layers behind it entirely, so the `data-frieren-wallpaper`
 * body attribute makes those surfaces see-through.
 *
 * Every surface that carries text keeps a palette-appropriate base instead of
 * going fully transparent:
 *
 * - the veil is white under the light palette (see
 *   {@link WALLPAPER_VEIL_BACKGROUND}), so the wallpaper is misted toward the
 *   near-black light ink rather than shaded away from it;
 * - the sidebar fill, the input card, and the message bubbles are re-bound to
 *   a strong translucent white in the light palette. Their defaults in that
 *   palette are near-white (`#f9fafb`, `#fff`, `#edf3fe`), so a fully
 *   transparent surface would drop near-black text straight onto the wallpaper
 *   and leave it unreadable on any dark image — at 62% white the text keeps
 *   its contrast even against a black one. The dark palette's values are
 *   untouched.
 */
export declare const WALLPAPER_TRANSPARENCY_CSS = "\nbody[data-frieren-wallpaper] {\n  --dsw-alias-bg-base: transparent;\n  --dsw-specific-sidebar-fill: transparent;\n  --dsw-specific-input-major: rgba(255, 255, 255, 0.15);\n  --dsw-specific-bubble: rgba(255, 255, 255, 0.12);\n  --fri-wallpaper-scrim-rgb: 0, 0, 0;\n}\nbody[data-frieren-wallpaper]:not([data-ds-dark-theme]) {\n  --fri-wallpaper-scrim-rgb: 255, 255, 255;\n  --dsw-specific-sidebar-fill: rgba(255, 255, 255, 0.62);\n  --dsw-specific-input-major: rgba(255, 255, 255, 0.62);\n  --dsw-specific-bubble: rgba(255, 255, 255, 0.62);\n}\nbody[data-ds-dark-theme][data-frieren-wallpaper] {\n  --dsw-specific-input-major: rgba(255, 255, 255, 0.06);\n  --dsw-specific-bubble: rgba(255, 255, 255, 0.05);\n}\n";
//# sourceMappingURL=wallpaper-css.d.ts.map