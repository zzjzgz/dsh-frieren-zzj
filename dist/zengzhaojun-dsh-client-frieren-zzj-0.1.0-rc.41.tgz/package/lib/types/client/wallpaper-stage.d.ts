import { type WallpaperPaintReason } from './wallpaper-transition.ts';
/** Everything the stage reads at paint time. */
export interface WallpaperStageState {
    /** The master switch is on and the gallery holds at least one image. */
    enabled: boolean;
    /** Wallpaper blur in px (clamped here like the layers do). */
    blurPx: number;
    /** Veil strength in percent (0–80). */
    dim: number;
    /** `prefers-reduced-motion: reduce` is active. */
    reducedMotion: boolean;
    /** The performance tier forbids heavy full-screen animation. */
    eco: boolean;
}
/** The injected world the stage draws in. */
export interface WallpaperStageDeps {
    /** Create one layer element (the stage sets its own dataset and styles). */
    createElement(): HTMLElement;
    /** Mount the created layers (the stage never touches `document` itself). */
    mount(nodes: readonly HTMLElement[]): void;
    /** The settings in force right now. */
    readState(): WallpaperStageState;
    /** Resolve once the image can be painted, or when the caller's timeout fires. */
    decode(url: string): Promise<void>;
}
/** The stage handle owned by the plugin effect. */
export interface WallpaperStage {
    /**
     * Show one wallpaper. `reason` decides whether the swap may animate: only
     * `'rotate'` does, and only when nothing downgrades it.
     * @param url - the image to show.
     * @param reason - what triggered this paint.
     */
    paint(url: string, reason: WallpaperPaintReason): void;
    /** Unmount every layer and drop whatever was in flight. */
    teardown(): void;
}
/**
 * Build a wallpaper stage.
 * @param deps - the injected world (element factory, mount point, settings, decode).
 * @returns the stage handle.
 */
export declare function createWallpaperStage(deps: WallpaperStageDeps): WallpaperStage;
//# sourceMappingURL=wallpaper-stage.d.ts.map