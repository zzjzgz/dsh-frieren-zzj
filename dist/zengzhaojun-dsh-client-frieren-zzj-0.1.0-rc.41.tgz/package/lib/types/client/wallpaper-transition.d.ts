/** Scale both wallpaper layers rest at. The layers' inline transform must
 * match it exactly, so an animation can end on its own resting frame without
 * a one-frame jump — and stay above 1 so a blur never shows its edges. */
export declare const WALLPAPER_REST_SCALE = 1.1;
/** Ceiling on the animated blur radius: re-rasterizing a full-screen blur every
 * frame is the expensive part of this effect, so the flight never blurs harder
 * than this no matter how blurry the wallpaper itself is set. */
export declare const MAX_ANIMATED_BLUR_PX = 26;
/** Why a wallpaper was painted. Only a rotation tick is worth animating:
 * settings changes (blur/dim sliders, uploads, the master switch) and the
 * first paint must land instantly or the UI would fly on every drag. */
export type WallpaperPaintReason = 'initial' | 'settings' | 'rotate';
/** Everything the planner needs to describe one swap. */
export interface WallpaperTransitionInput {
    /** What triggered the paint. */
    reason: WallpaperPaintReason;
    /** `prefers-reduced-motion: reduce` is active. */
    reducedMotion: boolean;
    /** The wallpaper performance tier is `eco` (no heavy full-screen animation). */
    eco: boolean;
    /** The user's wallpaper blur in px (out-of-range values clamp like the layer). */
    blurPx: number;
}
/** One layer's animation endpoints: scale, blur and opacity at each end. */
export interface WallpaperLayerFrames {
    /** Endpoints the layer animates from. */
    from: {
        scale: number;
        blurPx: number;
        opacity: number;
    };
    /** Endpoints the layer animates to. */
    to: {
        scale: number;
        blurPx: number;
        opacity: number;
    };
    /** Animation duration in milliseconds. */
    durationMs: number;
    /** CSS easing for the animation. */
    easing: string;
}
/** The two-layer plan. `animate: false` means the caller hard-cuts the swap. */
export type WallpaperTransitionPlan = {
    animate: false;
    kind: 'none';
} | {
    animate: true;
    kind: 'depth' | 'fade';
    incoming: WallpaperLayerFrames;
    outgoing: WallpaperLayerFrames;
};
/**
 * Resolve one wallpaper swap into layer animations.
 *
 * A plain crossfade and the depth flight share their shape — only the numbers
 * differ — so the caller applies one code path and the downgrades stay data.
 * @param input - paint reason, accessibility and performance gates, wallpaper blur.
 * @returns the plan; `kind: 'none'` means hard-cut.
 */
export declare function wallpaperTransitionPlan(input: WallpaperTransitionInput): WallpaperTransitionPlan;
//# sourceMappingURL=wallpaper-transition.d.ts.map