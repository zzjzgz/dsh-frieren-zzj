/** Durable settings owned by the Frieren theme plugin. */
import z from '@deepseek-ai/schemastery';
/** Settings namespace owned by the plugin; persisted in the user-settings document. */
export declare const FRIEREN_SETTINGS_NAMESPACE = "frieren-zzj";
/** Master plugin switch: off removes every theme effect and returns the default UI. */
export declare const ENABLED_FIELD = "enabled";
/** User-uploaded custom wallpaper, stored as a downscaled JPEG data URL. */
export declare const CUSTOM_WALLPAPER_FIELD = "customWallpaper";
/** Wallpaper blur radius in pixels (0 = sharp, 20 = heavy blur). */
export declare const WALLPAPER_BLUR_FIELD = "wallpaperBlur";
/** Blur ceiling in px: the radius the slider, the image layers, and the
 * fly-through's blur endpoints all clamp to. */
export declare const MAX_WALLPAPER_BLUR = 20;
/** Wallpaper dim (darkening overlay) percentage: 0 = off, 80 = heaviest shade. */
export declare const WALLPAPER_DIM_FIELD = "wallpaperDim";
/** Dim ceiling: the heaviest shade the slider offers (percent black overlay). */
export declare const MAX_WALLPAPER_DIM = 80;
/** Wallpaper gallery: rotation entries as a JSON array of data URLs ('' = none). */
export declare const WALLPAPERS_FIELD = "customWallpapers";
/** Rotation interval of the wallpaper gallery, in seconds. */
export declare const CAROUSEL_INTERVAL_FIELD = "carouselInterval";
/** Rotation order of the wallpaper gallery. */
export declare const CAROUSEL_MODE_FIELD = "carouselMode";
/** How many images the gallery may hold (every entry is a compressed JPEG). */
export declare const MAX_WALLPAPERS = 6;
/** Rotation order identifiers for the wallpaper gallery. */
export declare const WALLPAPER_ROTATIONS: readonly ["sequential", "shuffle"];
/** Rotation order identifier. */
export type WallpaperRotation = typeof WALLPAPER_ROTATIONS[number];
/** Default rotation order. */
export declare const DEFAULT_CAROUSEL_MODE: WallpaperRotation;
/** Shortest rotation interval the slider offers, in seconds. */
export declare const MIN_CAROUSEL_INTERVAL = 5;
/** Longest rotation interval the slider offers, in seconds. */
export declare const MAX_CAROUSEL_INTERVAL = 600;
/** Interval a fresh install starts on, in seconds. */
export declare const DEFAULT_CAROUSEL_INTERVAL = 30;
/** Input-bar material choice: frosted glass or the plain default surface. */
export declare const INPUT_MATERIAL_FIELD = "inputMaterial";
/** Per-element decoration switches (kept flat so each rides one settings path). */
export declare const DECOR_SPARKLES_FIELD = "decorSparkles";
export declare const DECOR_FLOWERS_FIELD = "decorFlowers";
export declare const DECOR_CIRCLE_FIELD = "decorCircle";
export declare const DECOR_RIBBON_FIELD = "decorRibbon";
export declare const DECOR_VIGNETTE_FIELD = "decorVignette";
/** Decoration tuning: element density, animation speed, magic-circle scale. */
export declare const DECOR_DENSITY_FIELD = "decorDensity";
export declare const DECOR_SPEED_FIELD = "decorSpeed";
export declare const CIRCLE_SCALE_FIELD = "decorCircleScale";
/** Focus mode: hide the animated decorations, keep wallpaper and theme chrome. */
export declare const FOCUS_MODE_FIELD = "focusMode";
/** Quote rotation mode for the composer dock line. */
export declare const QUOTE_MODE_FIELD = "quoteMode";
/** Custom fixed quote text (empty = use built-in classic line). */
export declare const CUSTOM_QUOTE_FIELD = "customQuote";
/** Custom random quote list (JSON string array; empty = use built-in library). */
export declare const CUSTOM_RANDOM_QUOTES_FIELD = "customRandomQuotes";
/** Quote rotation modes: random per change, or the fixed line. */
export declare const QUOTE_MODES: readonly ["random", "fixed"];
export type QuoteMode = typeof QUOTE_MODES[number];
/** Defaults mirrored in the schema; reads fall back here while a settings document is absent or stale. */
export declare const DEFAULT_QUOTE_MODE: QuoteMode;
/**
 * Overall materials: `glass` applies the iOS-style frosted-glass treatment
 * to the input card, task list, goal bar, and settings panel
 * (semi-transparent background, moderate backdrop blur with saturation boost,
 * translucent white border, soft directional shadow, generous rounding —
 * light/dark variants baked in, not user-adjustable); `plain` restores the
 * default surfaces.
 */
export declare const INPUT_MATERIALS: readonly ["glass", "plain"];
export type InputMaterial = typeof INPUT_MATERIALS[number];
/** Default input-bar material. */
export declare const DEFAULT_INPUT_MATERIAL: InputMaterial;
/** The five boolean decoration-layer keys of {@link DecorState}. */
export type DecorLayer = 'sparkles' | 'flowers' | 'circle' | 'ribbon' | 'vignette';
/** The five toggleable decoration layers of the wallpaper stage, plus their tuning. */
export interface DecorState {
    /** Twinkling gold / periwinkle star specks. */
    sparkles: boolean;
    /** Falling blue moon weed blossoms. */
    flowers: boolean;
    /** Top-right rotating magic circle. */
    circle: boolean;
    /** Top tricolor ribbon. */
    ribbon: boolean;
    /** Corner vignette. */
    vignette: boolean;
    /** Element density multiplier (0.25–2; 1 = the full set). */
    density: number;
    /** Animation speed multiplier (2 = twice as fast). */
    speed: number;
    /** Magic-circle scale multiplier. */
    circleScale: number;
}
/** One custom quote entry for the random quote table. */
export interface CustomQuoteEntry {
    /** Quote text (the line shown in the dock). */
    text: string;
    /** Speaker attribution (shown after the dash). */
    speaker: string;
    /** Optional tooltip gloss. */
    gloss: string;
}
/** Fully-resolved settings every consumer reads; every field is defined. */
export type ResolvedFrierenSettings = Required<FrierenSettings>;
/** Durable section shared by the Host schema and the browser scope. */
export interface FrierenSettings {
    /** Master switch: off disables every theme effect (wallpaper, decorations, fonts, glass, quotes). */
    enabled: boolean;
    /** Custom wallpaper data URL ('' = no wallpaper). */
    customWallpaper: string;
    /** Wallpaper blur radius in px (0-20, 0 = no blur). */
    wallpaperBlur: number;
    /** Wallpaper dim (darkening overlay) percentage (0-80, 0 = no shading). */
    wallpaperDim: number;
    /** Wallpaper gallery rotation entries (JSON array of data URLs; '' = single wallpaper only). */
    customWallpapers: string;
    /** Rotation interval of the gallery, in seconds (5-600). */
    carouselInterval: number;
    /** Rotation order of the gallery. */
    carouselMode: WallpaperRotation;
    /** Input-bar material: frosted glass or plain. */
    inputMaterial: InputMaterial;
    /** Decoration layer switches (see {@link DecorState}). */
    decorSparkles: boolean;
    decorFlowers: boolean;
    decorCircle: boolean;
    decorRibbon: boolean;
    decorVignette: boolean;
    /** Decoration tuning: element density (0.25–2), animation speed (0.25–4), magic-circle scale (0.5–2). */
    decorDensity: number;
    decorSpeed: number;
    decorCircleScale: number;
    /** Focus mode: decorations off, wallpaper and theme chrome kept. */
    focusMode: boolean;
    /** Quote rotation mode for the composer dock line. */
    quoteMode: QuoteMode;
    /** Custom fixed quote text (empty = use built-in classic Himmel line). */
    customQuote: string;
    /** Custom random quote list as JSON string array (empty = use built-in library). */
    customRandomQuotes: string;
}
/** The full default section: what a fresh install and the "restore defaults" action produce. */
export declare const DEFAULT_FRIEREN_SETTINGS: ResolvedFrierenSettings;
/**
 * Durable schema; also the wire envelope the browser scope validates against.
 *
 * DSH 0.2 owns plugin settings as the owning Loader entry's `config`, so this
 * schema is exported as the node half's `Config` and every field is marked
 * volatile: volatile nodes are the ones the settings service may rewrite live
 * (`SettingsForms.update/replace/mutate`) without remounting the plugin, and an
 * entry whose schema exposes no volatile field is not described at all.
 *
 * No explicit `z<FrierenSettings>` annotation: a volatile schema's inferred
 * output is `Volatile<FrierenSettings>` at the type level, while every consumer
 * reads the plain section through {@link FrierenSettings} / {@link resolveSettings}.
 */
export declare const FrierenSettingsSchema: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<boolean, boolean, "volatile-defined">;
    customWallpaper: z<string, string, "volatile-defined">;
    wallpaperBlur: z<number, number, "volatile-defined">;
    wallpaperDim: z<number, number, "volatile-defined">;
    customWallpapers: z<string, string, "volatile-defined">;
    carouselInterval: z<number, number, "volatile-defined">;
    carouselMode: z<"sequential" | "shuffle", "sequential" | "shuffle", "volatile-defined">;
    inputMaterial: z<"glass" | "plain", "glass" | "plain", "volatile-defined">;
    decorSparkles: z<boolean, boolean, "volatile-defined">;
    decorFlowers: z<boolean, boolean, "volatile-defined">;
    decorCircle: z<boolean, boolean, "volatile-defined">;
    decorRibbon: z<boolean, boolean, "volatile-defined">;
    decorVignette: z<boolean, boolean, "volatile-defined">;
    decorDensity: z<number, number, "volatile-defined">;
    decorSpeed: z<number, number, "volatile-defined">;
    decorCircleScale: z<number, number, "volatile-defined">;
    focusMode: z<boolean, boolean, "volatile-defined">;
    quoteMode: z<"random" | "fixed", "random" | "fixed", "volatile-defined">;
    customQuote: z<string, string, "volatile-defined">;
    customRandomQuotes: z<string, string, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<boolean, boolean, "volatile-defined">;
    customWallpaper: z<string, string, "volatile-defined">;
    wallpaperBlur: z<number, number, "volatile-defined">;
    wallpaperDim: z<number, number, "volatile-defined">;
    customWallpapers: z<string, string, "volatile-defined">;
    carouselInterval: z<number, number, "volatile-defined">;
    carouselMode: z<"sequential" | "shuffle", "sequential" | "shuffle", "volatile-defined">;
    inputMaterial: z<"glass" | "plain", "glass" | "plain", "volatile-defined">;
    decorSparkles: z<boolean, boolean, "volatile-defined">;
    decorFlowers: z<boolean, boolean, "volatile-defined">;
    decorCircle: z<boolean, boolean, "volatile-defined">;
    decorRibbon: z<boolean, boolean, "volatile-defined">;
    decorVignette: z<boolean, boolean, "volatile-defined">;
    decorDensity: z<number, number, "volatile-defined">;
    decorSpeed: z<number, number, "volatile-defined">;
    decorCircleScale: z<number, number, "volatile-defined">;
    focusMode: z<boolean, boolean, "volatile-defined">;
    quoteMode: z<"random" | "fixed", "random" | "fixed", "volatile-defined">;
    customQuote: z<string, string, "volatile-defined">;
    customRandomQuotes: z<string, string, "volatile-defined">;
}>>, "plain">;
/**
 * Narrow one wire value to a persistable quote mode.
 * @param value - value crossing the settings boundary.
 * @returns whether the value is a built-in quote mode.
 */
export declare function isQuoteMode(value: unknown): value is QuoteMode;
/**
 * Narrow one wire value to a persistable input material.
 * @param value - value crossing the settings boundary.
 * @returns whether the value is a built-in material.
 */
export declare function isInputMaterial(value: unknown): value is InputMaterial;
/**
 * Narrow one wire value to a persistable wallpaper rotation order.
 * @param value - value crossing the settings boundary.
 * @returns whether the value is a built-in rotation order.
 */
export declare function isWallpaperRotation(value: unknown): value is WallpaperRotation;
/**
 * Parse the custom random quotes JSON string into an array of entries.
 * Returns an empty array on any parse failure or invalid shape.
 * @param json - the stored JSON string (array of {text, speaker, gloss?}).
 * @returns the parsed quote entries, or empty on failure.
 */
export declare function parseCustomQuotes(json: string): CustomQuoteEntry[];
/**
 * Resolve a possibly-stale or partial settings value into a complete section:
 * the wire envelope validates against the schema but returns the stored value
 * as-is (defaults are not materialized), so every consumer reads through here.
 * @param value - the scope's decoded section, or undefined before first load.
 * @returns the fully-defaulted settings object.
 */
export declare function resolveSettings(value: Partial<FrierenSettings> | undefined): ResolvedFrierenSettings;
//# sourceMappingURL=frieren-settings.d.ts.map