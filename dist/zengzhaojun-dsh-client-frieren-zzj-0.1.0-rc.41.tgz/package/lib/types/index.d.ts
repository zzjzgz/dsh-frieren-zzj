/**
 * Frieren × Himmel web theme, node half.
 *
 * The node half owns the plugin's user-facing settings: it registers the
 * `frieren-zzj` settings namespace (the wallpaper switch) so the value is
 * served to the browser half and persisted in the user-settings document.
 *
 * The settings seam of the harness refuses browser RPCs for namespaces
 * outside its hardcoded allowlist (dsh-host-apiproxy answers
 * `settings-not-exposed` for `frieren-zzj`), so the browser half cannot use
 * the standard settings transport. To stay a pure profile-side plugin with
 * zero harness changes, this half ALSO registers a small exact HTTP route
 * that proxies one namespace read/write straight to the settings service.
 * The route lives under the `/plugins` prefix, so no harness trust fence or
 * allowlist applies to it; it is a same-origin contract with the browser
 * half of this package only.
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const Config: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
    enabled: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    customWallpaper: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    wallpaperBlur: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    wallpaperDim: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    customWallpapers: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    carouselInterval: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    carouselMode: import("@deepseek-ai/schemastery").default<"sequential" | "shuffle", "sequential" | "shuffle", "volatile-defined">;
    inputMaterial: import("@deepseek-ai/schemastery").default<"glass" | "plain", "glass" | "plain", "volatile-defined">;
    decorSparkles: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorFlowers: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorCircle: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorRibbon: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorVignette: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorDensity: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    decorSpeed: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    decorCircleScale: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    focusMode: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    quoteMode: import("@deepseek-ai/schemastery").default<"random" | "fixed", "random" | "fixed", "volatile-defined">;
    customQuote: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    customRandomQuotes: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    customWallpaper: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    wallpaperBlur: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    wallpaperDim: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    customWallpapers: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    carouselInterval: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    carouselMode: import("@deepseek-ai/schemastery").default<"sequential" | "shuffle", "sequential" | "shuffle", "volatile-defined">;
    inputMaterial: import("@deepseek-ai/schemastery").default<"glass" | "plain", "glass" | "plain", "volatile-defined">;
    decorSparkles: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorFlowers: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorCircle: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorRibbon: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorVignette: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    decorDensity: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    decorSpeed: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    decorCircleScale: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    focusMode: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    quoteMode: import("@deepseek-ai/schemastery").default<"random" | "fixed", "random" | "fixed", "volatile-defined">;
    customQuote: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    customRandomQuotes: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
}>>, "plain">;
/** Exact route the browser half fetches to read/write this plugin's settings. */
export declare const SETTINGS_BRIDGE_PATH = "/plugins/@zengzhaojun/dsh-client-frieren-zzj/settings";
/** Host plugin body — expose the theme settings form and its browser bridge. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map