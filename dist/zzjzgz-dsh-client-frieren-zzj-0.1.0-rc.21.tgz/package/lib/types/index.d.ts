/**
 * Frieren × Himmel web theme, node half.
 *
 * The node half owns the plugin's user-facing settings: it registers the
 * `frieren-zzj` settings namespace (the wallpaper switch) so the value is
 * served to the browser half and persisted in the user-settings document.
 *
 * The settings seam of the harness refuses browser RPCs for namespaces
 * outside its hardcoded allowlist (dsh-host-apiproxy answers
 * `settings-not-exposed` for `frieren-zzj`), so the browser half cannot use
 * the standard settings transport. To stay a pure profile-side plugin with
 * zero harness changes, this half ALSO registers a small exact HTTP route
 * that proxies one namespace read/write straight to the settings service.
 * The route lives under the `/plugins` prefix, so no harness trust fence or
 * allowlist applies to it; it is a same-origin contract with the browser
 * half of this package only.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Exact route the browser half fetches to read/write this plugin's settings. */
export declare const SETTINGS_BRIDGE_PATH = "/plugins/@zzjzgz/dsh-client-frieren-zzj/settings";
/** Host plugin body — register the wallpaper switch's durable section and its browser bridge. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map